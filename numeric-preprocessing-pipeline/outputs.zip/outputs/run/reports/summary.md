# Preprocessing Run Summary

*Run window (UTC):* 2026-10-27T18:16:36Z → 2026-10-27T18:16:36Z · *Seed:* 42

## 1. Inputs & snapshot

| input file | rows | sha256 |
|---|---|---|
| synthetic_messy.csv | 5100 | b30970967e83… |

Ingested snapshot: **5,100 rows × 22 columns** → `data.parquet`

| column | coercion | dtype | unresolved→null |
|---|---|---|---|
| id | integer_cast | Int64 | 0 |
| x_normal | float_cast | Float64 | 0 |
| x_uniform | float_cast | Float64 | 0 |
| x_exponential | float_cast | Float64 | 0 |
| x_bimodal | float_cast | Float64 | 0 |
| x_lognormal | float_cast | Float64 | 0 |
| denominator | float_cast | Float64 | 0 |
| const_col | float_cast | Float64 | 0 |
| near_const | float_cast | Float64 | 0 |
| mostly_null | float_cast | Float64 | 0 |
| x_corr_strong | float_cast | Float64 | 0 |
| x_corr_moderate | float_cast | Float64 | 0 |
| numerator | float_cast | Float64 | 0 |
| x_mixed_format | float_cast | Float64 | 0 |
| x_percent_string | float_cast | Float64 | 0 |
| target | float_cast | Float64 | 0 |

## 2. Data-quality findings

| column | null % | unique | skew | flags |
|---|---|---|---|---|
| all_null_col | 100.00 | 1 | — | constant |
| mostly_null | 96.71 | 164 | 0.053 | — |
| x_lognormal | 15.20 | 4244 | 7.604 | — |
| x_bimodal | 10.10 | 4497 | -0.024 | — |
| cat_bool | 9.94 | 3 | — | near-constant |
| x_exponential | 7.98 | 4583 | — | — |
| numerator | 6.73 | 4667 | 0.018 | — |
| x_corr_moderate | 6.31 | 4686 | -0.030 | — |
| cat_low | 4.82 | 6 | — | near-constant |
| denominator | 4.80 | 4765 | 0.019 | — |

- Duplicate rows removed: **100**
- ±inf values nulled: **48**
| high-corr pair | r |
|---|---|
| x_normal ~ target | 1.0000 |
| denominator ~ numerator | 0.9940 |
| x_uniform ~ x_corr_moderate | 0.9254 |

| potential leakage column | reasons |
|---|---|
| target | name matches leakage pattern |


## 3. Split

- Strategy: **random** · sizes {'train': 3500, 'val': 750, 'test': 750} · applied ratios {'train': 0.7, 'val': 0.15, 'test': 0.15}

## 4. Fitted decisions (train only)

| dropped column | reason (train-fitted) |
|---|---|
| id | id-like: name matches '(?i)^(id|.*[_-]id|uuid|guid|index|row_?num|.*[_-]num)$' or train unique ratio >= 0.999 |
| timestamp | id-like: name matches '(?i)^(id|.*[_-]id|uuid|guid|index|row_?num|.*[_-]num)$' or train unique ratio >= 0.999 |
| const_col | constant on train (zero variance) |
| all_null_col | train null rate 1.0000 > threshold 0.95 |
| mostly_null | train null rate 0.9691 > threshold 0.95 |

- Imputation: **median** on 25 numeric column(s); 12 missing-indicator column(s) added.
- Outliers: **winsorize** bounds fitted for 25 column(s); clipping counts logged per partition.
_none_

- Encoding: one-hot applied to 2 column(s); 1 dropped (high cardinality).
- Selection: 1 column(s) dropped.
| column | scaler | reason |
|---|---|---|
| x_normal | standard | auto: |skew|=0.144 < skew_moderate 0.5 → standard |
| x_uniform | standard | auto: |skew|=0.019 < skew_moderate 0.5 → standard |
| x_exponential | power | auto: |skew|=1.628 >= skew_high 1 → Yeo-Johnson |
| x_bimodal | standard | auto: |skew|=0.164 < skew_moderate 0.5 → standard |
| x_lognormal | power | auto: |skew|=2.844 >= skew_high 1 → Yeo-Johnson |
| denominator | standard | auto: |skew|=0.019 < skew_moderate 0.5 → standard |
| cat_cat_low__alpha | none | excluded by scaling.exclude_patterns '^cat_' |
| cat_cat_low__beta | none | excluded by scaling.exclude_patterns '^cat_' |
| cat_cat_low__delta | none | excluded by scaling.exclude_patterns '^cat_' |
| cat_cat_low__gamma | none | excluded by scaling.exclude_patterns '^cat_' |
| cat_cat_low__omega | none | excluded by scaling.exclude_patterns '^cat_' |
| cat_cat_bool__False | none | excluded by scaling.exclude_patterns '^cat_' |
| cat_cat_bool__True | none | excluded by scaling.exclude_patterns '^cat_' |
| x_corr_strong | standard | auto: |skew|=0.016 < skew_moderate 0.5 → standard |
| x_corr_moderate | standard | auto: |skew|=0.038 < skew_moderate 0.5 → standard |
| numerator | standard | auto: |skew|=0.005 < skew_moderate 0.5 → standard |
| x_mixed_format | standard | auto: |skew|=0.055 < skew_moderate 0.5 → standard |
| x_percent_string | standard | auto: |skew|=0.019 < skew_moderate 0.5 → standard |
| target | power | auto: |skew|=2.606 >= skew_high 1 → Yeo-Johnson |
| x_lognormal__was_missing | none | excluded by scaling.exclude_patterns '__was_missing$' |
| x_bimodal__was_missing | none | excluded by scaling.exclude_patterns '__was_missing$' |
| cat_bool__was_missing | none | excluded by scaling.exclude_patterns '^cat_' |
| x_exponential__was_missing | none | excluded by scaling.exclude_patterns '__was_missing$' |
| x_corr_moderate__was_missing | none | excluded by scaling.exclude_patterns '__was_missing$' |
| numerator__was_missing | none | excluded by scaling.exclude_patterns '__was_missing$' |


## 5. Assumptions

- Split-first discipline: all fitted statistics were learned on the train partition only; val/test were transformed, never fitted.
- The audit is informational — no fitted decision consumes audit output.
- Exact duplicate rows are removed pre-split (stateless, prevents cross-split straddling); near-duplicates are reported, not removed.
- Column-drop decisions (null ceiling, constants, ID-like) were fitted on train statistics only.
- Outlier handling clips values to train-fitted bounds; rows are never dropped after the split.
- Engineered features with non-finite values are replaced with train medians of the engineered outputs.
- Unseen categories in val/test map to all-zero one-hot rows.
- The target column was never imputed, scaled, or used in any fit.

## 6. Recommended next steps

- Columns with >30% nulls (all_null_col, mostly_null): review upstream collection; heavy imputation degrades signal quality.
- Potential target-leakage columns were flagged in the audit — inspect them before modeling; consider dropping post-outcome fields at the source.
- Yeo-Johnson was applied to 3 skewed column(s); if these are count/monetary features, consider transforming at the source instead.
- 1 feature(s) were correlation-pruned; if interpretability matters, prefer domain-driven retention over automatic pruning.
- 100 duplicate rows were removed; if duplicates recur between runs, add upstream uniqueness constraints.
- Validate downstream model quality with cross-validation on the train split only; treat val/test as untouched until final reporting.
- Version the raw inputs and this run's manifest with DVC (or an equivalent data registry) so every model can be traced to exact bytes.

## 7. Reproduction

```bash
# deterministic rerun (same input + config + image ⇒ byte-identical outputs)
make run   # or: numprep run --config <cfg> --input <dir> --output <dir>
```

| output | sha256 |
|---|---|
| train | aff451f7e11454b18ddc7e5280753725101805c2a011c0adaefaab5a1583c042 |
| val | f2c0c6b16c79de5d893acb76ce8a49f39e5b7de19ed276bf74020ad464df51d5 |
| test | 28b73d399170e4c5d1563817d5e550783cfed9b8e91bb811abee98f8ee773568 |

Manifest SHA-256: `304f05a5b43dc7a117a1a881afe93f41a7544b3112c81474edea1468dc58f0f0`

Library context: python 3.14.2, numprep 1.0.0, numpy 2.5.4, pandas 2.3.3, polars 2.1.0, pyarrow 26.0.0, scikit-learn 1.9.1, pydantic 2.14.1
